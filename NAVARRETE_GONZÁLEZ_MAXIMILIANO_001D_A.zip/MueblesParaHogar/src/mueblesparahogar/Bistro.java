/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mueblesparahogar;

/**
 *
 * @author Usuario
 */
public class Bistro extends Mueble {
    private final double diametroMesa;

    public Bistro(int id, String nombre, double precio, double diametroMesa) {
        super(id, nombre, precio);
        this.diametroMesa = diametroMesa;
    }

    @Override
    public String generarDescripcion() {
        return "Bistro - Diámetro: " + diametroMesa + "m";
    }
}

