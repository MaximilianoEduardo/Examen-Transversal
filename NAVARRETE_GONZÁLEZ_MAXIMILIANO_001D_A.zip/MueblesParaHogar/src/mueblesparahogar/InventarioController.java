/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mueblesparahogar;

import java.util.ArrayList;

/**
 *
 * @author Usuario
 */
public class InventarioController {
    private final ArrayList<Mueble> inventario;

    public InventarioController() {
        inventario = new ArrayList<>();
    }

    public void agregarMueble(Mueble mueble) {
        inventario.add(mueble);
    }

    public boolean eliminarMueble(int id) {
        return inventario.removeIf(m -> m.getId() == id);
    }

    public String listarInventario() {
        StringBuilder sb = new StringBuilder();
        for (Mueble m : inventario) {
            sb.append(m.getId())
              .append(" - ")
              .append(m.getNombre())
              .append(" - ")
              .append(m.generarDescripcion())
              .append("\n");
        }
        return sb.toString();
    }
}
