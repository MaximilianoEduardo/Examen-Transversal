/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mueblesparahogar;

/**
 *
 * @author Usuario
 */
public class Comedor extends Mueble {
    private final int capacidadPersonas;

    public Comedor(int id, String nombre, double precio, int capacidadPersonas) {
        super(id, nombre, precio);
        this.capacidadPersonas = capacidadPersonas;
    }

    /**
     *
     * @return
     */
    @Override
    public String generarDescripcion() {
        return "Comedor - Capacidad: " + capacidadPersonas;
    }
}

