/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package mueblesparahogar;

/**
 *
 * @author Usuario
 */
public class Living extends Mueble {
    private final int numeroSofas;
    private final boolean incluyeCojines;

    public Living(int id, String nombre, double precio, int numeroSofas, boolean incluyeCojines) {
        super(id, nombre, precio);
        this.numeroSofas = numeroSofas;
        this.incluyeCojines = incluyeCojines;
    }

    @Override
    public String generarDescripcion() {
        return "Living - Sofás: " + numeroSofas + " Cojines: " + incluyeCojines;
    }
}

